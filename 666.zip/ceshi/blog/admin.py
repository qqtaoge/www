from django.contrib import admin
from blog.models import *
# Register your models here.
class BlogsPostAdmin(admin.ModelAdmin):
    list_display = ('title','timestamp')
admin.site.register(BlogsPost,BlogsPostAdmin)
admin.site.register(Tag)
admin.site.register(Category)
admin.site.register(Head)
