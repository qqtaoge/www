from django.db import models

# Create your models here.
from django.contrib import admin
# Create your models here.
from ckeditor.fields import RichTextField
import markdown
from django.utils.html import strip_tags

on_delete=models.CASCADE
class Tag(models.Model):
    #博客标签
    name = models.CharField('标签',max_length=16)

    def __str__(self):
        return self.name

class Category(models.Model):
    """
    Django 要求模型必须继承 models.Model 类。
    Category 只需要一个简单的分类名 name 就可以了。
    CharField 指定了分类名 name 的数据类型，CharField 是字符型，
    CharField 的 max_length 参数指定其最大长度，超过这个长度的分类名就不能被存入数据库。
    当然 Django 还为我们提供了多种其它的数据类型，如日期时间类型 DateTimeField、整数类型 IntegerField 等等。
    Django 内置的全部类型可查看文档：
    https://docs.djangoproject.com/en/1.10/ref/models/fields/#field-types
    """
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name



class BlogsPost(models.Model):
    title = models.CharField(u'标题',max_length = 150)
    zhaiyao = models.TextField(u'摘要',blank=True)
    body = RichTextField(blank=True,null=True,verbose_name="内容")
    timestamp = models.DateTimeField()
    # 新增 views 字段记录阅读量
    views = models.PositiveIntegerField(default=0)

    category = models.ForeignKey(Category,on_delete=models.CASCADE,)
    tags = models.ManyToManyField(Tag,verbose_name='标签',blank=True)


    #tu = models.CharField(u'文章图片地址',max_length=150,default="")
    def __str__(self):
        return self.title

    def increase_views(self):
        self.views += 1
        self.save(update_fields=['views'])

    def save(self, *args, **kwargs):
        # 如果没有填写摘要
        if not self.zhaiyao:
            # 首先实例化一个 Markdown 类，用于渲染 body 的文本
            md = markdown.Markdown(extensions=[
                'markdown.extensions.extra',
                'markdown.extensions.codehilite',
            ])
            # 先将 Markdown 文本渲染成 HTML 文本
            # strip_tags 去掉 HTML 文本的全部 HTML 标签
            # 从文本摘取前 54 个字符赋给 excerpt
            self.zhaiyao = strip_tags(md.convert(self.body))[:54]

        # 调用父类的 save 方法将数据保存到数据库中
        super(BlogsPost, self).save(*args, **kwargs)

class Head(models.Model):
    title = models.CharField(u'标题', max_length=150)
    tou1 = models.CharField(u'头1', max_length=150)
    tou2 = models.CharField(u'头2', max_length=150)
    jianjie = RichTextField(blank=True,null=True,verbose_name="简介")
    jianjie_url = models.CharField(u'简介头像', max_length=150,default=u'/static/images/avatar.png')
    keywords = models.CharField(u'首页关键字', max_length=150)
    description = models.TextField(u'描述',blank=True)