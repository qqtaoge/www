﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","fi",{title:"Elementin tiedot",dialogName:"Dialogi-ikkunan nimi",tabName:"Välilehden nimi",elementId:"Elementin ID",elementType:"Elementin tyyppi"});